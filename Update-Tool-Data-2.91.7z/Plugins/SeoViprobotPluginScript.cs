﻿using AForge.Imaging.Filters;
using AutoManager.Commons;
using AutoManager.Plugins.TestPlugins;
using AutoManager.Recognition;
using AutoManager.Recognition.Russ;
using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace AutoManager.Plugins
{

    [PluginInfo(PluginName = "All1Tool - Seo-Viprobot")]
    [Export(typeof(All1PluginScript))]
    class SeoViprobotPluginScript : All1PluginScript
    {

        private Queue<string> _linkQueue;

        public override All1ActionResult Begin(object arg)
        {
            Client.GetRequest("loginform.php");
            return new All1NextMethodResult { NextMethod = SubmitLogin };
        }

        private All1ActionResult SubmitLogin(object arg)
        {
            //Nếu đã login ko cần login lại

            if (!Client.ResponseStr.Contains("logout.php"))
            {

                Dictionary<string, string> dic = new Dictionary<string, string>();
                dic.Add("username", Username);
                dic.Add("password", Password);

                Bitmap captBm = Client.GetBitmap("logincap.php", Client.ResponseFullUrl);
                GrifonbuxCaptRecognizer rec = new GrifonbuxCaptRecognizer();
                string result = rec.Recognize(captBm).ToString();
                dic.Add("code", result);

                Client.PostRequest("login.php", dic);
                if (Client.ResponseStr.Contains("Неправильно введён"))
                {
                    return new All1NextMethodResult { NextMethod = Begin };
                }
                if (!Client.ResponseStr.Contains("location.replace(\"members.php\");"))
                {
                    return new All1StopingResult { Reason = "LoginFailed" };
                }
            }

            Client.GetRequest("wiews_sites.php");
            HtmlNodeCollection nodes = Client.ResponseDoc.DocumentNode.SelectNodes("//a[starts-with(@onclick,'javascript: this.style.textDecoration=')]");

            _linkQueue = new Queue<string>();
            if (nodes != null)
            {
                foreach (HtmlNode node in nodes)
                {
                    //Nó có phần để kiểm tra auto, cẩn thận!!!!
                    var style = node.ParentNode.Attributes["style"];
                    if (style != null)
                    {
                        if (style.Value.Contains("none") || style.Value.Contains("hidden"))
                        {
                            continue;
                        }
                    }
                    if (!IsCheatLink(node.InnerText))
                    {
                        string url = node.Attributes["href"].Value;
                        _linkQueue.Enqueue(url);
                    }

                }
            }

            return new All1NextMethodResult { NextMethod = ProcessAdPage, Option = ActionOption.SaveCookie };
        }

      

        private All1ActionResult ProcessAdPage(object arg)
        {

            if (_linkQueue.Count <= 0)
            {
                return new All1NextMethodResult { NextMethod = End };
            }
            string currentAdLink = _linkQueue.Peek();
            Client.GetRequest(currentAdLink, "vlews_sites.php");
            string previousUrl = Client.ResponseFullUrl;
            Client.GetRequest("vfa.php", previousUrl);
            Client.GetRequest("vls.php", previousUrl);

            var timerNode = Client.ResponseDoc.GetElementbyId("time");
            if (timerNode == null)
            {
                timerNode = Client.ResponseDoc.GetElementbyId("timer_inp");
            }
            int timer = 10;
            if (!string.IsNullOrEmpty(timerNode.InnerText))
            {
                timer = int.Parse(timerNode.InnerText)+5;
            }

            return new All1WaitingAdResult
            {
                WaitingTime = timer,
                RemainAds = _linkQueue.Count,
                NextMethod = (o) =>
                {
                    Client.GetRequest("vls.php?view=ok", Client.ResponseFullUrl);

                    Bitmap bm = Client.GetBitmap("image.php?Array", Client.ResponseFullUrl);
                    int result = ColorStarRecognizer.Recognize(bm);
                    Client.PostRequest("vls.php?view=ok&ds=clicked", "code=" + result, Client.ResponseFullUrl);
                    _linkQueue.Dequeue();
                    return new All1NextMethodResult { NextMethod = ProcessAdPage };
                }
            };

        }

        public override All1ActionResult End(object arg)
        {
            Client.GetRequest("members.php");
            HtmlNode textNode = Client.ResponseDoc.DocumentNode.SelectSingleNode("//td[text()='На балансе:']");
            Amount = ParseHelper.GetAmount(textNode.ParentNode.InnerText);
            return new All1ActionResult { Message = "Finish" };
        }
    }

}
