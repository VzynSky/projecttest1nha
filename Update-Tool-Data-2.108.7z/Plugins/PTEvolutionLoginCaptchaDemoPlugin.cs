﻿using AutoManager.Plugins;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TestOnlineLibrary.Components;
namespace TestOnlineLibrary
{

     [PluginInfo(PluginName = "All1 - PTEvolutionLoginCaptchaDemoPlugin")]
   // [PluginInfoEx(SiteOrReferer = "http://bdnprojects.net", Description = "Hello world! ")]
    public class PTEvolutionLoginCaptchaDemoPlugin : All1PluginScript
    {
        public override All1ActionResult Begin(object arg)
        {
            var bitmap = Client.GetBitmap("http://buxvertise.com/modules/captcha/captcha.php?r=login");
            
            
            return new All1PTEvolutionLoginCaptchaResult{ Bm = bitmap, NextMethod = End };
        }

        public override All1ActionResult End(object arg)
        {
            // captcha result here
            var captchaResult = CaptchaResultStr;
            // if CaptchaResultStr == null, that means get captcha failed, we will try again with another captcha
            return new All1StopingResult { Reason = "Hello" };
        }
    }
}
