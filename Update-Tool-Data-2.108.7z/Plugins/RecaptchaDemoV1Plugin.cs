﻿using AutoManager.Plugins;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TestOnlineLibrary.Components;
namespace TestOnlineLibrary
{

  //  [PluginInfo(PluginName = "All1 - RecaptchaDemoV1Plugin")]
   // [PluginInfoEx(SiteOrReferer = "http://bdnprojects.net", Description = "Hello world! ")]
    public class RecaptchaDemoV1Plugin : All1PluginScript
    {
        public override All1ActionResult Begin(object arg)
        {
            Client.GetRequest("http://www.patcurtis.com/captcha/recaptcha_demo.php");
            
            var info = Client.GetRecaptchaInfo();
            var ChallengeField = info.ChallengeField;
            return new All1RecaptchaV1Result { Info = info, NextMethod = End };
        }

        public override All1ActionResult End(object arg)
        {
            // captcha result here
            var captchaResult = CaptchaResultStr;
            return new All1StopingResult { Reason = "Hello" };
        }
    }
}
