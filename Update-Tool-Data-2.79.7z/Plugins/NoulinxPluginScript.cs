﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using AutoManager.Plugins;
using HtmlAgilityPack;
using AutoManager.Commons;
using System.Text.RegularExpressions;

namespace Noulinx
{
    [Export(typeof(All1PluginScript))]
    [PluginInfo(PluginName = "All1Tool - Noulinx")]
    public class NoulinxPluginScript : All1PluginScript
    {

        private Queue<string> _linkQueue;

        public override All1ActionResult Begin(object arg)
        {
            Client.DetectGoogleAnalytic = true;
            Client.GetRequest("?p=lo");
            return new All1NextMethodResult { NextMethod = SubmitLogin };
        }

        private All1ActionResult SubmitLogin(object arg)
        {
            if (Client.ResponseStr.Contains("You are now logged out"))
            {
                Client.ClearCookie();
                Client.GetRequest("?p=lo");
            }
            if (!Client.ResponseStr.Contains("The access to this page is restricted"))
            {
                Dictionary<string, string> dic = new Dictionary<string, string>();
                dic.Add("username", Username);
                string password = Password;
                if (password.Length > 10)
                {
                    password = password.Substring(0, 10);
                }
                dic.Add("password", password);
                Client.PostRequest("?p=lo", dic, Client.ResponseFullUrl);
                if (!Client.ResponseStr.Contains("You are being logged in"))
                {
                    return new All1StopingResult { Reason = "LoginFailed" };
                }
            }

            Client.GetRequest("?p=ad");
            HtmlNodeCollection nodes = Client.ResponseDoc.DocumentNode.SelectNodes("//a[starts-with(@href,'v/?h=')]");

            _linkQueue = new Queue<string>();
            if (nodes != null)
            {
                foreach (HtmlNode node in nodes)
                {
                    if (!IsCheatLink(node.ParentNode.ParentNode.InnerText) && !node.ParentNode.Attributes["class"].Value.Contains("adV"))
                    {
                        string url = node.Attributes["href"].Value;
                        _linkQueue.Enqueue(url);
                    }

                }
            }

            return new All1NextMethodResult { NextMethod = ProcessAdPage };
        }

        private string GetValueSeparateByEqualSign(string inputStr, string leftSideStr)
        {
            Regex regex = new Regex(string.Format("{0}\\s*=\\s*([^,;&]+)", leftSideStr));
            Match m = regex.Match(inputStr);
            if (m.Groups.Count > 1)
            {
                return m.Groups[1].Value;
            }
            return null;
        }

        private All1ActionResult ProcessAdPage(object arg)
        {

            if (_linkQueue.Count <= 0)
            {
                return new All1NextMethodResult { NextMethod = End };
            }
            string currentAdLink = _linkQueue.Peek();

            Client.GetRequest(currentAdLink, "?p=ad");            
            
            return new All1WaitingAdResult
            {
                WaitingTime = 60,
                RemainAds = _linkQueue.Count,
                NextMethod = (o) =>
                {
                    string verf = GetValueSeparateByEqualSign(Client.ResponseStr, "verf").Replace("\"","");
                    string hash = GetValueSeparateByEqualSign(Client.ResponseStr, "hash").Replace("\"", "");   
                 
                    Client.PostRequest("v/?p=val",hash+"&"+verf, Client.ResponseFullUrl,true);                    
                    _linkQueue.Dequeue();
                    return new All1NextMethodResult { NextMethod = ProcessAdPage };
                }
            };

        }
        public override All1ActionResult End(object arg)
        {
            Client.GetRequest("?p=ma");

            HtmlNode textNode = Client.ResponseDoc.DocumentNode.SelectSingleNode("//td[text()='Main balance:']");
            Amount = ParseHelper.GetAmount(textNode.ParentNode.InnerText);

            return new All1ActionResult { Message = "Finish" };
        }
    }
}
