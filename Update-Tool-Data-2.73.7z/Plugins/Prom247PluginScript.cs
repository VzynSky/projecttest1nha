﻿using AutoManager.Commons;
using AutoManager.Plugins.TestPlugins;
using AutoManager.Recognition.Russ;
using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Drawing;
using System.Linq;
using System.Text;

namespace AutoManager.Plugins
{

    [PluginInfo(PluginName = "All1Tool - Prom247")]
    [Export(typeof(All1PluginScript))]
    class Prom247PluginScript : All1PluginScript
    {

        private Queue<string> _linkQueue;

        public override All1ActionResult Begin(object arg)
        {
            // Gửi request tới server để login
            Client.GetRequest("login.html");


            //Lấy hình ảnh captcha bằng hàm GetBitmap và trả về hình ảnh kiểu bitmap.
            Bitmap bm = Client.GetBitmap("image2.php?$res");

            
            //Lúc này ta cần hiện captcha đó trên màn hình, và nhận thông tin mà người dùng nhập vào.
            // bạn có thể dễ dàng làm việc đó bằng cách, new 1 class kiểu All1WaitTextCaptResult, tham số Image truyền vào là 
            //hình ảnh captcha bạn vừa lấy ở phía trên.
            // Chúng ta cần truyền phương thức tiếp theo sau khi ta đã thoát ra phương thức hiện tại, bằng cách truyền vào biến
            //NextMethod, ở đây phương thức tiếp theo của ta là SubmitLogin.
            return new All1WaitTextCaptResult { Image = bm, NextMethod = SubmitLogin };
        }

        private All1ActionResult SubmitLogin(object arg)
        {
            // Chúng ta sẽ tạo một biến kiểu Dictionary để chứa thông tin data mình cần gửi đến server.
            Dictionary<string, string> dic = new Dictionary<string, string>();

            dic.Add("logusername", Username); //Username của người dùng nhập
            dic.Add("logpassword", Password);// Password của người dùng nhập

            //Lúc này biến CaptchaResultStr của lớp All1PluginScript đã chứa thông tin người dùng nhập
            // Để biết được những chuổi như là logusername,logpassword,code ở đâu ra, thì bạn phải dùng fiddler để nhận biết.
            dic.Add("code", CaptchaResultStr);

            //Ok, Nào ta gửi request tới trang login.php với data mình vừa nhập vào dic.
            //Tham số đầu là link cần gửi, tham số thứ 2 là data cần gửi
            Client.PostRequest("login.php", dic);

            //Lúc này ta có thể kiểm tra nội dung trang web trả về có chứa chuỗi prom247.com/exit.html hay không.
            // Biến ResponseStr sẽ chứa nội dung của trang web dưới dạng chuỗi.
            // Nếu có thì có nghĩa ta đã đăng nhập thành công, nếu không ta trả về biế kiểu All1StopingResult.
            // Khi tool thấy ta trả về kiểu này, có nghĩa rằng ta muốn dừng chạy plugin. Ta có thể thêm
            // lý do ta ngừng chạy thông qua biến Reason.
            if (!Client.ResponseStr.Contains("prom247.com/exit.html"))
            {
                return new All1StopingResult { Reason = "LoginFailed" };
            }

            
            // Đăng nhập thành công rồi, thì ta vào trang web chính chứa các ad.
            Client.GetRequest("sites.php");
            // Tới đây bạn sẽ để ý rằng có khi ta dùng hàm GetRequest và PostRequest, để biết được dùng hàm nào thì đó là dựa vào kiểu request
            // mà trang web đó thực sự cần. Bạn cần phải xem thông tin đó bằng cách dùng Fiddler.

            // Chúng ta kiểm tra xem, trang này có cần ta nhập captcha trước khi hiện ra danh sách các ad hay không.
            if (Client.ResponseStr.Contains("specify the number of stars in the picture"))
            {
                // Nếu tới đây có nghĩa rằng ta cần nhập captcha.
                // Lấy hình ảnh của captcha.
                Bitmap captchaBm = Client.GetBitmap("image.php?Array");

                //Lớp ColorStarRecognizer là 1 lớp do mình viết sẵn, mục đính là đếm số ngôi sao chứa trong captcha.                
                int result = ColorStarRecognizer.Recognize(captchaBm);

                //Sau khi đã biết được bao nhiêu ngôi sao, ta sẽ gửi request trả lời đáp an cho web.
                // Tham số đầu là link cần gửi, tham số 2 là data cần gửi, ở đây ta không cần dùng dạng dictionary để gửi data.
                // ta có thể truyền dưới dạng chuổi và có format như sau name=value.
                // Tham số cuối cùng là link hiện tại mà mình đang đứng để gửi request, tham số này ko thực sự quan trọng, nhưng 
                // vài trang web đòi hỏi ta phải có thông tin này. Đó là thông tin tương ứng với Header referer của request.
                Client.PostRequest("sites.php", "code=" + result, Client.ResponseFullUrl);

                //Ta giả sử kết quả ta gửi là chính xác, lúc này ta chỉ cần gửi request lại lần nữa cho trang xem danh sách các ad                
                Client.GetRequest("sites.php");
            }

            //Như bạn đã biết, khi lấy thông tin 1 trang web, ngoài trả về kiểu chuỗi, tool còn trả về một kiều cây DOM.
            //Kiểu này cho phép bạn duyệt, tìm kiếm thông tin các thẻ Html 1 cách nhanh chóng.
            // Để dùng được bạn cần add reference tới thư viện Agility Html, dll này có sẵn trong thư mục All1Tool, có tên là: HtmlAgilityPack.dll
            //ở đây câu trên có nghĩa rằng, tìm tất cả thẻ a trong trang web, có attribte href được bắt đầu bằng chuỗi '/adview'
            // thực chất chuổi bên trong hàm SelectNodes là cú pháp của XPath, được dùng để tìm thông tin của 1 node trong DOM tree.
            // Nếu bạn chưa biết XPath là gì, thì nên google về nó:D
            // Câu lệnh sẽ trả về một tập các node tìm được.
            HtmlNodeCollection nodes = Client.ResponseDoc.DocumentNode.SelectNodes("//a[starts-with(@href,'/adview')]");
            
            //Khởi tạo 1 queue, ta sẽ chứa thông tin các ad tìm được trong đây.
            _linkQueue = new Queue<string>();

            if (nodes != null)
            {
                foreach (HtmlNode node in nodes)
                {
                    //Dòng lệnh này đảm bảo rằng ta kiểm tra không có cheat text nào có trong ad đó.                     
                    if (!IsCheatLink(node.ParentNode.InnerText))
                    { 
                        // Nếu có vẻ ổn thỏa, lấy đường dẫn của ad đó, và thêm vào queue
                        string url = node.Attributes["href"].Value;
                        _linkQueue.Enqueue(url);
                    }

                }
            }

            //ok, ta chuyển tới hàm kế tiếp.
            return new All1NextMethodResult { NextMethod = ProcessAdPage};
        }

        private All1ActionResult ProcessAdPage(object arg)
        {
            //Ta kiểm tra queue còn ad không, nếu không còn ta sẽ chuyển ngay tới phương End.
            if (_linkQueue.Count <= 0)
            {
                return new All1NextMethodResult { NextMethod = End };
            }
            // lấy thông tin của ad, hàm peek lấy 1 phần tử, chưa thật sự lấy ra khỏi queue
            string currentAdLink = _linkQueue.Peek();

            //Gửi request tới ad vừa lấy ra, truyển thêm tham số sites.php, để thông báo cho web rằng, ta đang đứng ở trang sites và gửi request.
            Client.GetRequest(currentAdLink, "sites.php");

            //Dựa vào Fiddle, ta biết rằng ta phải gửi request tới link vls.php
            Client.GetRequest("vls.php", Client.ResponseFullUrl);

            //Tới lú này, thông tin trang web từ link vls.php sẽ được trả về
            // Nhờ vào Fiddler, đọc nội dung được trả về, ta biết được rằng thời gian chờ nằm trong thẻ có id là sfbtimer.
            // Dùng hàm GetElementbyId ta có thể lấy được thông tin của node đó
            HtmlNode timerNode = Client.ResponseDoc.GetElementbyId("sfbtimer");

            // chuyển từ kiểu chuổi sang int
            int timer = int.Parse(timerNode.InnerText);

            //Ok, đây là hàm khá nhiều thứ trong đây.
            // Với lớp All1WaitingAdResult được trả về từ hàm nay, thì tool sẽ biết rằng tool cần chờ trong khoảng một thời gian, thời gian chờ
            // sẽ được biết thông qua Biến WaitingTime của lớp. Ví dụ nếu gán 10, thì tool sẽ chờ 10 giây, đồng thời hiện thông tin đếm thời gian trên giao diện.
            //Biến RemainAds chứa số lượng ad còn lại trong biến queue
            // Tiếp theo, tương tự như ở trên, ta cần truyển phương thức tiếp theo cho biến NextMethod.
            // Nhưng khác biệt ở đây là ta dùng dạng rút gọn, định nghĩa phương thức thẳng bên trong lúc new class. bạn có thể nghĩ thay vì định nghĩa
            // phương thức bên ngoài, thì nay ta định nghĩa thẳng bên trong.
            // Đây là lamda expression hỗ trợ bởi C#, nếu bạn chưa quen có thể google để biết thêm.
            return new All1WaitingAdResult
            {
                WaitingTime = timer,
                RemainAds = _linkQueue.Count,
                NextMethod = (o) =>
                {
                    // Dựa vào fiddle ta biết được rằng, cần gửi request tới link vls.php?view=ok, để lấy thông tin captcha.
                    Client.GetRequest("vls.php?view=ok", Client.ResponseFullUrl);

                    // Lấy thông tin hình ảnh captcha và đếm sao :D
                    Bitmap captchaImage = Client.GetBitmap("image.php?Resource id #5", Client.ResponseFullUrl);
                    int result = ColorStarRecognizer.Recognize(captchaImage);

                    // Gửi thông tin số lượng sao đến server.
                    Client.PostRequest("vls.php?view=ok&ds=clicked", "code=" + result, Client.ResponseFullUrl);
                    
                    //Cứ cho là ok, thì lúc này ta thực sự xóa 1 phần từ ra khỏi queue
                    _linkQueue.Dequeue();
                    //Ta gọi lại hàm ProcessAdPage
                    return new All1NextMethodResult { NextMethod = ProcessAdPage };
                }
            };

        }


        public override All1ActionResult End(object arg)
        {
            //Lúc này là hàm end, sau khi gọi hàm này, tool sẽ stop plugin luôn, vì vậy lúc này ta lấy thông tin số tiền ta hiện có của trang web.
            // Gửi request đến trang profile.html.
            Client.GetRequest("profile.html");

            //Dùng XPath để kiếm node, có text là All you have earned:
            HtmlNode textNode = Client.ResponseDoc.DocumentNode.SelectSingleNode("//b[text()='All you have earned:']");
            // từ đó ta có thể lấy được số tiền, hàm dưới có thể lấy được con số xuất hiện đầu tiên trong chuỗi.
            Amount = ParseHelper.GetAmount(textNode.ParentNode.ParentNode.InnerText);

            // Như vậy là đã xong, ta chỉ cần trả về lớp All1ActionResult, thực chất lớp này chính là lớp cha của tất cả các lớp Result mà các hàm trên trả về
            return new All1ActionResult { Message = "Finish" };
        }
    }
}
