﻿using AutoManager.Plugins;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TestOnlineLibrary.Components;
namespace TestOnlineLibrary
{

   // [PluginInfo(PluginName = "All1 - SolveMediaCaptDemoPlugin")]
   // [PluginInfoEx(SiteOrReferer = "http://bdnprojects.net", Description = "Hello world! ")]
    public class SolveMediaCaptDemoPlugin : All1PluginScript
    {
        public override All1ActionResult Begin(object arg)
        {
            Client.GetRequest("http://wsnippets.com/demo/solve-media-captcha-php/index.php#sthash.RXFzo6xi.dpbs");
            
            var info = Client.GetSolveMediaCaptInfo();
            var t = info.Bm;
            return new All1SolveMediaCaptchaResult { Info = info, NextMethod = End };
        }

        public override All1ActionResult End(object arg)
        {
            // captcha result here
            var captchaResult = CaptchaResultStr;
            return new All1StopingResult { Reason = "Hello" };
        }
    }
}
