﻿using AutoManager.Commons;
using AutoManager.Plugins.TestPlugins;
using AutoManager.Recognition.Russ;
using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace AutoManager.Plugins
{

    [PluginInfo(PluginName = "All1Tool - Wordlinx")]
    [Export(typeof(All1PluginScript))]
    class WordlinxPluginScript : All1PluginScript
    {

        private Queue<string> _linkQueue;
        private Queue<string> _linkQueue2;

        public override All1ActionResult Begin(object arg)
        {            
            Client.GetRequest("login.php");
            return new All1NextMethodResult {NextMethod = SubmitLogin };
        }

        private All1ActionResult SubmitLogin(object arg)
        {
            //Nếu đã login ko cần login lại
            if (Client.ResponseFullUrl.Contains("login.php"))
            {
               // string hash = Client.ResponseDoc.DocumentNode.SelectSingleNode("//input[@name='hash']").Attributes["value"].Value;
                Dictionary<string, string> dic = new Dictionary<string, string>();
                dic.Add("Username", Username);
                dic.Add("Password", Password);

                Client.PostRequest("login.php", dic);
                if (Client.ResponseStr.Contains("You have exceeded the number of login attempts permitted"))
                {
                    return new All1StopingResult { Reason = "exceeded number login attempts" };

                }
                if (Client.ResponseFullUrl.Contains("login.php"))
                {
                    return new All1StopingResult { Reason = "LoginFailed" };
                }
            }

            string clickScript = Client.GetSeparateRequest("scripts/click.js");
            if(clickScript.Length!=2843)
            {
                return new All1StopingResult { Reason = "Script changed" };
            }

            Client.GetRequest("browse.php");
            HtmlNodeCollection nodes = Client.ResponseDoc.DocumentNode.SelectNodes("//a[starts-with(@href,'advert-browse.php?sc=')]");

            _linkQueue = new Queue<string>();
            _linkQueue2 = new Queue<string>();
            if (nodes != null)
            {
                foreach (HtmlNode node in nodes)
                {
                    if (!IsCheatLink(node.ParentNode.ParentNode.InnerText))
                    { 
                        string url = node.Attributes["href"].Value;
                        _linkQueue.Enqueue(url);
                        string id = node.ParentNode.ParentNode.ParentNode.ParentNode.ParentNode.Attributes["id"].Value;
                        url = "includes/misclick.inc.php?aid={0}&sid={1}";
                        var result=id.Split("_".ToCharArray());
                        url = string.Format(url, result[1], result[2]);
                        _linkQueue2.Enqueue(url);
                    }

                }
            }

            return new All1NextMethodResult { NextMethod = ProcessAdPage,Option=ActionOption.SaveCookie};
        }

        private string GetValueSeparateByEqualSign(string inputStr, string leftSideStr)
        {
            Regex regex = new Regex(string.Format("{0}\\s*=\\s*([^,;&]+)", leftSideStr));
            Match m = regex.Match(inputStr);
            if (m.Groups.Count > 1)
            {
                return m.Groups[1].Value;
            }
            return null;
        }
        private string GetValueSeparateNumberByEqualSign(string inputStr, string leftSideStr)
        {
            Regex regex = new Regex(string.Format("{0}\\s*=\\s*([0-9]+)", leftSideStr));
            Match m = regex.Match(inputStr);
            if (m.Groups.Count > 1)
            {
                return m.Groups[1].Value;
            }
            return null;
        }

        private All1ActionResult ProcessAdPage(object arg)
        {
            
            if (_linkQueue.Count <= 0)
            {
                return new All1NextMethodResult { NextMethod = End };
            }
            string currentAdLink = _linkQueue.Peek();
            string otherLink=_linkQueue2.Peek();
            Client.GetSeparateRequest(otherLink, "browse.php");
            Client.GetRequest(currentAdLink, "browse.php");

            string timerStr = GetValueSeparateNumberByEqualSign(Client.ResponseStr, "counter");
            int timer = int.Parse(timerStr);
          
            return new All1WaitingAdResult
            {
                WaitingTime = timer,
                RemainAds = _linkQueue.Count,
                NextMethod = (o) =>
                {
                    string id = GetValueSeparateByEqualSign(Client.ResponseFullUrl, "id");
                    string sc = GetValueSeparateByEqualSign(Client.ResponseFullUrl, "sc");
                    Client.GetRequest("credit-account.php?sc="+sc+"&id="+id,Client.ResponseFullUrl);
                    _linkQueue.Dequeue();
                    _linkQueue2.Dequeue();
                    return new All1NextMethodResult { NextMethod = ProcessAdPage };
                }
            };

        }

        public override All1ActionResult End(object arg)
        {            
            Client.GetRequest("cashout.php");
            HtmlNode textNode = Client.ResponseDoc.DocumentNode.SelectSingleNode("//td[text()='Total Earned']");            
            Amount = ParseHelper.GetAmount(textNode.ParentNode.InnerText);            
            return new All1ActionResult { Message = "Finish" };
        }
    }
}
