﻿using AutoManager.Plugins;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TestOnlineLibrary.Components;
namespace TestOnlineLibrary
{

   // [PluginInfo(PluginName = "All1 - RecaptchaDemoV2Plugin")]
   // [PluginInfoEx(SiteOrReferer = "http://bdnprojects.net", Description = "Hello world! ")]
    public class RecaptchaDemoV2Plugin : All1PluginScript
    {
        public override All1ActionResult Begin(object arg)
        {
            Client.GetRequest("https://www.google.com/recaptcha/api2/demo");
      
            return new All1RecaptchaV2Result { PageUrl = "https://www.google.com/recaptcha/api2/demo", NextMethod = End };
        }

        public override All1ActionResult End(object arg)
        {
            // captcha result here
            var captchaResult = CaptchaResultStr;
            return new All1StopingResult { Reason = "Hello" };
        }
    }
}
