﻿using AutoManager.Commons;
using AutoManager.Plugins.TestPlugins;
using AutoManager.Recognition.Russ;
using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace AutoManager.Plugins
{

    [PluginInfo(PluginName = "All1Tool - Tapbux")]
    [Export(typeof(All1PluginScript))]
    class TapbuxPluginScript : All1PluginScript
    {

        private Queue<string> _linkQueue;

        public override All1ActionResult Begin(object arg)
        {           
            Client.GetRequest("login");
            return new All1NextMethodResult {NextMethod = SubmitLogin };
        }

        private All1ActionResult SubmitLogin(object arg)
        {
            string hash = Client.ResponseDoc.DocumentNode.SelectSingleNode("//input[@name='hash']").Attributes["value"].Value;
            Dictionary<string, string> dic = new Dictionary<string, string>();            
            dic.Add("username", Username); 
            dic.Add("password", Password);
            dic.Add("hash", hash);
            Client.PostRequest("index.php?i=l ", dic);

            if (!Client.ResponseStr.Contains("success"))
            {
                return new All1StopingResult { Reason = "LoginFailed" };
            }

            Client.GetRequest("viewads");
            HtmlNodeCollection nodes = Client.ResponseDoc.DocumentNode.SelectNodes("//a[starts-with(@href,'/?i=v&p=k&token=')]");

            _linkQueue = new Queue<string>();
            if (nodes != null)
            {
                foreach (HtmlNode node in nodes)
                {
                    if (!IsCheatLink(node.ParentNode.ParentNode.InnerText) && !node.ParentNode.ParentNode.OuterHtml.Contains("widget ad-widget viewed"))
                    { 
                        string url = node.Attributes["href"].Value;
                        _linkQueue.Enqueue(url);
                    }

                }
            }

            return new All1NextMethodResult { NextMethod = ProcessAdPage};
        }

        private string GetValueSeparateByEqualSign(string inputStr, string leftSideStr)
        {
            Regex regex = new Regex(string.Format("{0}\\s*=\\s*([^,;&]+)", leftSideStr));
            Match m = regex.Match(inputStr);
            if (m.Groups.Count > 1)
            {
                return m.Groups[1].Value;
            }
            return null;
        }

        private All1ActionResult ProcessAdPage(object arg)
        {
            
            if (_linkQueue.Count <= 0)
            {
                return new All1NextMethodResult { NextMethod = End };
            }
            string currentAdLink = _linkQueue.Peek();
            Client.GetRequest(currentAdLink, "viewads");

            string timerStr = GetValueSeparateByEqualSign(Client.ResponseStr, "time");
            string token = GetValueSeparateByEqualSign(Client.ResponseStr, "token").Replace("\"","");
            string key = GetValueSeparateByEqualSign(Client.ResponseStr, "key").Replace("\"", "");
            string stime = GetValueSeparateByEqualSign(Client.ResponseStr, "stime");
            Dictionary<string,string> data=new Dictionary<string,string>();
            data.Add("key",key);
            data.Add("token",token);
            data.Add("time",timerStr);
            data.Add("stime",stime);
            int timer = int.Parse(timerStr);
          
            return new All1WaitingAdResult
            {
                WaitingTime = timer,
                RemainAds = _linkQueue.Count,
                NextMethod = (o) =>
                {
                    Client.PostRequest("index.php?i=v&p=k&token=" + token, data, Client.ResponseFullUrl);
                    _linkQueue.Dequeue();
                    return new All1NextMethodResult { NextMethod = ProcessAdPage };
                }
            };

        }

        public override All1ActionResult End(object arg)
        {            
            Client.GetRequest("account");
            HtmlNode textNode = Client.ResponseDoc.DocumentNode.SelectSingleNode("//td[text()='Main Balance']");            
            Amount = ParseHelper.GetAmount(textNode.ParentNode.InnerText);            
            return new All1ActionResult { Message = "Finish" };
        }
    }
}
